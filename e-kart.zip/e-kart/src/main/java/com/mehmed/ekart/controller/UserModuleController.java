package com.mehmed.ekart.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mehmed.ekart.constant.AppConstant;

@RestController
@RequestMapping(value =AppConstant.USER_API)
public class UserModuleController {

	
	
	
	
	
	
	
}
