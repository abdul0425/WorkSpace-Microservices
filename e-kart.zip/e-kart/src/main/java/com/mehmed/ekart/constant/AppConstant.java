package com.mehmed.ekart.constant;

public interface AppConstant {

	public String USER_API = "/userApi";
	public String PRODUCT_API = "/productApi";
	public String GET_ALL_PRODUCTS = "/getAllProducts";
	
}
